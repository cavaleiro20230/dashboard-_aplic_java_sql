// Conexão com SQL Server usando o pacote mssql
import sql from "mssql"

// Configuração de conexão com o SQL Server
const sqlConfig = {
  user: process.env.DB_USER || "",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "",
  server: process.env.DB_SERVER || "",
  pool: {
    max: 10,
    min: 0,
    idleTimeoutMillis: 30000,
  },
  options: {
    encrypt: true, // Para conexões Azure
    trustServerCertificate: true, // Mudar para false em produção
  },
}

// Função para executar consultas SQL
export async function executeQuery(query: string, params: any[] = []) {
  try {
    await sql.connect(sqlConfig)
    const request = new sql.Request()

    // Adiciona parâmetros à consulta
    params.forEach((param, index) => {
      request.input(`param${index}`, param)
    })

    const result = await request.query(query)
    return result.recordset
  } catch (err) {
    console.error("Erro ao executar consulta SQL:", err)
    throw err
  } finally {
    await sql.close()
  }
}

// Funções específicas para consultas financeiras
export async function getRevenueExpenseData(startDate?: string, endDate?: string) {
  const dateFilter = startDate && endDate ? `WHERE data BETWEEN @param0 AND @param1` : ""

  const query = `
    SELECT 
      FORMAT(data, 'MMM') as mes,
      SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END) as receitas,
      SUM(CASE WHEN tipo = 'DESPESA' THEN valor ELSE 0 END) as despesas
    FROM vw_MovimentacaoFinanceira
    ${dateFilter}
    GROUP BY FORMAT(data, 'MMM'), MONTH(data)
    ORDER BY MONTH(data)
  `

  return executeQuery(query, startDate && endDate ? [startDate, endDate] : [])
}

export async function getProfitMarginData(startDate?: string, endDate?: string) {
  const dateFilter = startDate && endDate ? `WHERE data BETWEEN @param0 AND @param1` : ""

  const query = `
    SELECT 
      FORMAT(data, 'MMM') as mes,
      (SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END) - 
       SUM(CASE WHEN tipo = 'DESPESA' THEN valor ELSE 0 END)) / 
       NULLIF(SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END), 0) * 100 as margem
    FROM vw_MovimentacaoFinanceira
    ${dateFilter}
    GROUP BY FORMAT(data, 'MMM'), MONTH(data)
    ORDER BY MONTH(data)
  `

  return executeQuery(query, startDate && endDate ? [startDate, endDate] : [])
}

export async function getCashFlowData(startDate?: string, endDate?: string) {
  const dateFilter = startDate && endDate ? `WHERE data BETWEEN @param0 AND @param1` : ""

  const query = `
    SELECT 
      FORMAT(data, 'MMM') as mes,
      SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END) as entradas,
      SUM(CASE WHEN tipo = 'DESPESA' THEN valor ELSE 0 END) as saidas,
      SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE -valor END) as saldo
    FROM vw_MovimentacaoFinanceira
    ${dateFilter}
    GROUP BY FORMAT(data, 'MMM'), MONTH(data)
    ORDER BY MONTH(data)
  `

  return executeQuery(query, startDate && endDate ? [startDate, endDate] : [])
}

export async function getAccountsReceivable(status?: string) {
  const statusFilter = status ? `WHERE status = @param0` : ""

  const query = `
    SELECT 
      id,
      cliente,
      documento,
      FORMAT(emissao, 'dd/MM/yyyy') as emissao,
      FORMAT(vencimento, 'dd/MM/yyyy') as vencimento,
      'R$ ' + FORMAT(valor, 'N2') as valor,
      status
    FROM vw_ContasReceber
    ${statusFilter}
    ORDER BY vencimento
  `

  return executeQuery(query, status ? [status] : [])
}

export async function getAccountsPayable(status?: string) {
  const statusFilter = status ? `WHERE status = @param0` : ""

  const query = `
    SELECT 
      id,
      fornecedor,
      documento,
      FORMAT(emissao, 'dd/MM/yyyy') as emissao,
      FORMAT(vencimento, 'dd/MM/yyyy') as vencimento,
      'R$ ' + FORMAT(valor, 'N2') as valor,
      status
    FROM vw_ContasPagar
    ${statusFilter}
    ORDER BY vencimento
  `

  return executeQuery(query, status ? [status] : [])
}

export async function getFinancialMetrics() {
  const query = `
    SELECT 
      (SELECT SUM(valor) FROM vw_MovimentacaoFinanceira WHERE tipo = 'RECEITA' AND MONTH(data) = MONTH(GETDATE()) AND YEAR(data) = YEAR(GETDATE())) as receitaTotal,
      (SELECT SUM(valor) FROM vw_MovimentacaoFinanceira WHERE tipo = 'DESPESA' AND MONTH(data) = MONTH(GETDATE()) AND YEAR(data) = YEAR(GETDATE())) as despesaTotal,
      (SELECT 
        (SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END) - 
         SUM(CASE WHEN tipo = 'DESPESA' THEN valor ELSE 0 END)) 
       FROM vw_MovimentacaoFinanceira 
       WHERE MONTH(data) = MONTH(GETDATE()) AND YEAR(data) = YEAR(GETDATE())) as lucroLiquido,
      (SELECT 
        SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE -valor END)
       FROM vw_MovimentacaoFinanceira 
       WHERE MONTH(data) = MONTH(GETDATE()) AND YEAR(data) = YEAR(GETDATE())) as fluxoCaixa,
      (SELECT 
        (SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END) - 
         SUM(CASE WHEN tipo = 'DESPESA' THEN valor ELSE 0 END)) / 
         NULLIF(SUM(CASE WHEN tipo = 'RECEITA' THEN valor ELSE 0 END), 0) * 100
       FROM vw_MovimentacaoFinanceira 
       WHERE MONTH(data) = MONTH(GETDATE()) AND YEAR(data) = YEAR(GETDATE())) as margemLucro
  `

  return executeQuery(query)
}

