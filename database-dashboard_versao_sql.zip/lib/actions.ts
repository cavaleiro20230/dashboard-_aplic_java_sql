"use server"

import {
  getAccountsPayable,
  getAccountsReceivable,
  getCashFlowData,
  getFinancialMetrics,
  getProfitMarginData,
  getRevenueExpenseData,
} from "./sql-server"

// Ações do servidor para buscar dados financeiros
export async function fetchFinancialMetrics() {
  try {
    const metrics = await getFinancialMetrics()
    return metrics[0] || {}
  } catch (error) {
    console.error("Erro ao buscar métricas financeiras:", error)
    throw new Error("Falha ao buscar métricas financeiras")
  }
}

export async function fetchRevenueExpenseData(startDate?: string, endDate?: string) {
  try {
    return await getRevenueExpenseData(startDate, endDate)
  } catch (error) {
    console.error("Erro ao buscar dados de receitas e despesas:", error)
    throw new Error("Falha ao buscar dados de receitas e despesas")
  }
}

export async function fetchProfitMarginData(startDate?: string, endDate?: string) {
  try {
    return await getProfitMarginData(startDate, endDate)
  } catch (error) {
    console.error("Erro ao buscar dados de margem de lucro:", error)
    throw new Error("Falha ao buscar dados de margem de lucro")
  }
}

export async function fetchCashFlowData(startDate?: string, endDate?: string) {
  try {
    return await getCashFlowData(startDate, endDate)
  } catch (error) {
    console.error("Erro ao buscar dados de fluxo de caixa:", error)
    throw new Error("Falha ao buscar dados de fluxo de caixa")
  }
}

export async function fetchAccountsReceivable(status?: string) {
  try {
    return await getAccountsReceivable(status)
  } catch (error) {
    console.error("Erro ao buscar contas a receber:", error)
    throw new Error("Falha ao buscar contas a receber")
  }
}

export async function fetchAccountsPayable(status?: string) {
  try {
    return await getAccountsPayable(status)
  } catch (error) {
    console.error("Erro ao buscar contas a pagar:", error)
    throw new Error("Falha ao buscar contas a pagar")
  }
}

