import { NextResponse } from "next/server"
import {
  getAccountsPayable,
  getAccountsReceivable,
  getCashFlowData,
  getFinancialMetrics,
  getProfitMarginData,
  getRevenueExpenseData,
} from "@/lib/sql-server"

// Rota para obter métricas financeiras
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const dataType = searchParams.get("type")
    const startDate = searchParams.get("startDate") || undefined
    const endDate = searchParams.get("endDate") || undefined
    const status = searchParams.get("status") || undefined

    let data

    switch (dataType) {
      case "metrics":
        data = await getFinancialMetrics()
        break
      case "revenue-expense":
        data = await getRevenueExpenseData(startDate, endDate)
        break
      case "profit-margin":
        data = await getProfitMarginData(startDate, endDate)
        break
      case "cash-flow":
        data = await getCashFlowData(startDate, endDate)
        break
      case "receivables":
        data = await getAccountsReceivable(status)
        break
      case "payables":
        data = await getAccountsPayable(status)
        break
      default:
        return NextResponse.json({ error: "Tipo de dados inválido" }, { status: 400 })
    }

    return NextResponse.json(data)
  } catch (error) {
    console.error("Erro ao buscar dados financeiros:", error)
    return NextResponse.json({ error: "Erro ao buscar dados financeiros" }, { status: 500 })
  }
}

