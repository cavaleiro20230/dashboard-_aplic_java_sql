"use client"

import { useState } from "react"
import { CreditCard, DollarSign, Download, FileText, Filter, RefreshCw, TrendingUp, Wallet } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DateRangePicker } from "@/components/date-range-picker"
import { FinancialMetric } from "@/components/financial-metric"
import { RevenueExpenseChart } from "@/components/revenue-expense-chart"
import { AccountsReceivableChart } from "@/components/accounts-receivable-chart"
import { ProfitMarginChart } from "@/components/profit-margin-chart"
import { CashFlowChart } from "@/components/cash-flow-chart"
import { FinancialTable } from "@/components/financial-table"
import { FilterDrawer } from "@/components/filter-drawer"

export default function Dashboard() {
  const [isLoading, setIsLoading] = useState(false)
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  const refreshData = async () => {
    setIsLoading(true)
    // In a real implementation, this would trigger a refresh of all data
    await new Promise((resolve) => setTimeout(resolve, 1000))
    setIsLoading(false)
  }

  return (
    <div className="flex flex-col h-full">
      <header className="border-b bg-card">
        <div className="container flex items-center justify-between py-4">
          <h1 className="text-2xl font-bold">Painel Financeiro & Contábil</h1>
          <div className="flex items-center gap-4">
            <DateRangePicker />
            <Button variant="outline" size="icon" onClick={() => setIsFilterOpen(true)}>
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filtrar</span>
            </Button>
            <Button variant="outline" size="icon" onClick={refreshData} disabled={isLoading}>
              <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin" : ""}`} />
              <span className="sr-only">Atualizar dados</span>
            </Button>
          </div>
        </div>
      </header>

      <div className="container py-6 space-y-6 flex-1">
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <FinancialMetric
            title="Receita Total"
            value="R$ 1.245.678,90"
            trend="+8.5%"
            description="Comparado ao mês anterior"
            icon={<DollarSign className="h-4 w-4" />}
          />
          <FinancialMetric
            title="Despesas"
            value="R$ 876.543,21"
            trend="+2.3%"
            trendNegative={true}
            description="Comparado ao mês anterior"
            icon={<CreditCard className="h-4 w-4" />}
          />
          <FinancialMetric
            title="Lucro Líquido"
            value="R$ 369.135,69"
            trend="+12.7%"
            description="Comparado ao mês anterior"
            icon={<TrendingUp className="h-4 w-4" />}
          />
          <FinancialMetric
            title="Fluxo de Caixa"
            value="R$ 289.456,78"
            trend="-3.5%"
            trendNegative={true}
            description="Comparado ao mês anterior"
            icon={<Wallet className="h-4 w-4" />}
          />
        </div>

        <Tabs defaultValue="overview">
          <TabsList>
            <TabsTrigger value="overview">Visão Geral</TabsTrigger>
            <TabsTrigger value="statements">Demonstrativos</TabsTrigger>
            <TabsTrigger value="receivables">Contas a Receber</TabsTrigger>
            <TabsTrigger value="payables">Contas a Pagar</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Receitas vs Despesas</CardTitle>
                  <CardDescription>Análise mensal comparativa</CardDescription>
                </CardHeader>
                <CardContent>
                  <RevenueExpenseChart />
                </CardContent>
              </Card>
              <Card>
                <CardHeader>
                  <CardTitle>Margem de Lucro</CardTitle>
                  <CardDescription>Evolução da margem de lucro</CardDescription>
                </CardHeader>
                <CardContent>
                  <ProfitMarginChart />
                </CardContent>
              </Card>
              <Card className="md:col-span-2">
                <CardHeader>
                  <CardTitle>Fluxo de Caixa</CardTitle>
                  <CardDescription>Entradas e saídas mensais</CardDescription>
                </CardHeader>
                <CardContent>
                  <CashFlowChart />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="statements">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Demonstrativos Financeiros</CardTitle>
                  <CardDescription>Relatórios contábeis e financeiros</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Exportar
                </Button>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="grid gap-4 md:grid-cols-2">
                    <Button variant="outline" className="h-auto py-4 justify-start">
                      <div className="flex flex-col items-start text-left">
                        <div className="flex items-center">
                          <FileText className="mr-2 h-4 w-4" />
                          <span className="font-medium">Balanço Patrimonial</span>
                        </div>
                        <span className="text-xs text-muted-foreground mt-1">Atualizado em 31/05/2023</span>
                      </div>
                    </Button>
                    <Button variant="outline" className="h-auto py-4 justify-start">
                      <div className="flex flex-col items-start text-left">
                        <div className="flex items-center">
                          <FileText className="mr-2 h-4 w-4" />
                          <span className="font-medium">DRE - Demonstrativo de Resultados</span>
                        </div>
                        <span className="text-xs text-muted-foreground mt-1">Atualizado em 31/05/2023</span>
                      </div>
                    </Button>
                    <Button variant="outline" className="h-auto py-4 justify-start">
                      <div className="flex flex-col items-start text-left">
                        <div className="flex items-center">
                          <FileText className="mr-2 h-4 w-4" />
                          <span className="font-medium">Fluxo de Caixa Detalhado</span>
                        </div>
                        <span className="text-xs text-muted-foreground mt-1">Atualizado em 31/05/2023</span>
                      </div>
                    </Button>
                    <Button variant="outline" className="h-auto py-4 justify-start">
                      <div className="flex flex-col items-start text-left">
                        <div className="flex items-center">
                          <FileText className="mr-2 h-4 w-4" />
                          <span className="font-medium">Relatório de Impostos</span>
                        </div>
                        <span className="text-xs text-muted-foreground mt-1">Atualizado em 31/05/2023</span>
                      </div>
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="receivables">
            <div className="grid gap-4 grid-cols-1">
              <Card>
                <CardHeader>
                  <CardTitle>Contas a Receber</CardTitle>
                  <CardDescription>Análise de recebíveis por período</CardDescription>
                </CardHeader>
                <CardContent>
                  <AccountsReceivableChart />
                </CardContent>
              </Card>
              <Card>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle>Detalhamento de Recebíveis</CardTitle>
                    <CardDescription>Faturas pendentes e recebidas</CardDescription>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="mr-2 h-4 w-4" />
                    Exportar
                  </Button>
                </CardHeader>
                <CardContent>
                  <FinancialTable type="receivables" />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="payables">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle>Contas a Pagar</CardTitle>
                  <CardDescription>Faturas e pagamentos pendentes</CardDescription>
                </div>
                <Button variant="outline" size="sm">
                  <Download className="mr-2 h-4 w-4" />
                  Exportar
                </Button>
              </CardHeader>
              <CardContent>
                <FinancialTable type="payables" />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>

      <FilterDrawer open={isFilterOpen} onClose={() => setIsFilterOpen(false)} />
    </div>
  )
}

