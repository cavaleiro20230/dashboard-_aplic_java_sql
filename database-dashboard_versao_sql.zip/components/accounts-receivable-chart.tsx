"use client"

import { Bar, BarChart, CartesianGrid, Legend, Tooltip, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { status: "A vencer", "0-30": 120000, "31-60": 45000, "61-90": 25000, ">90": 15000 },
  { status: "Vencidos", "0-30": 35000, "31-60": 28000, "61-90": 18000, ">90": 42000 },
]

export function AccountsReceivableChart() {
  return (
    <ChartContainer
      config={{
        "0-30": {
          label: "0-30 dias",
          color: "hsl(var(--chart-1))",
        },
        "31-60": {
          label: "31-60 dias",
          color: "hsl(var(--chart-2))",
        },
        "61-90": {
          label: "61-90 dias",
          color: "hsl(var(--chart-3))",
        },
        ">90": {
          label: ">90 dias",
          color: "hsl(var(--chart-4))",
        },
      }}
      className="h-[300px]"
    >
      <BarChart
        data={data}
        layout="vertical"
        margin={{
          top: 5,
          right: 10,
          left: 100,
          bottom: 20,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" horizontal={false} />
        <XAxis
          type="number"
          tickFormatter={(value) => `R$${value / 1000}k`}
          tickLine={false}
          axisLine={false}
          tickMargin={10}
        />
        <YAxis type="category" dataKey="status" tickLine={false} axisLine={false} tickMargin={10} />
        <Tooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) => `${value}`}
              valueFormatter={(value) => `R$${value.toLocaleString("pt-BR")}`}
            />
          }
        />
        <Legend wrapperStyle={{ bottom: 0 }} />
        <Bar dataKey="0-30" fill="var(--color-0-30)" />
        <Bar dataKey="31-60" fill="var(--color-31-60)" />
        <Bar dataKey="61-90" fill="var(--color-61-90)" />
        <Bar dataKey=">90" fill="var(--color->90)" />
      </BarChart>
    </ChartContainer>
  )
}

