"use client"

import { Bar, BarChart, CartesianGrid, Legend, Tooltip, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { month: "Jan", receitas: 120000, despesas: 85000 },
  { month: "Fev", receitas: 135000, despesas: 90000 },
  { month: "Mar", receitas: 145000, despesas: 95000 },
  { month: "Abr", receitas: 160000, despesas: 100000 },
  { month: "Mai", receitas: 175000, despesas: 110000 },
  { month: "Jun", receitas: 162000, despesas: 105000 },
  { month: "Jul", receitas: 170000, despesas: 108000 },
  { month: "Ago", receitas: 180000, despesas: 112000 },
  { month: "Set", receitas: 190000, despesas: 115000 },
  { month: "Out", receitas: 185000, despesas: 118000 },
  { month: "Nov", receitas: 195000, despesas: 120000 },
  { month: "Dez", receitas: 210000, despesas: 125000 },
]

export function RevenueExpenseChart() {
  return (
    <ChartContainer
      config={{
        receitas: {
          label: "Receitas",
          color: "hsl(var(--chart-1))",
        },
        despesas: {
          label: "Despesas",
          color: "hsl(var(--chart-2))",
        },
      }}
      className="h-[300px]"
    >
      <BarChart
        data={data}
        margin={{
          top: 5,
          right: 10,
          left: 10,
          bottom: 20,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={10} />
        <YAxis tickFormatter={(value) => `R$${value / 1000}k`} tickLine={false} axisLine={false} tickMargin={10} />
        <Tooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) => `${value}`}
              valueFormatter={(value) => `R$${value.toLocaleString("pt-BR")}`}
            />
          }
        />
        <Legend wrapperStyle={{ bottom: 0 }} />
        <Bar dataKey="receitas" fill="var(--color-receitas)" radius={[4, 4, 0, 0]} />
        <Bar dataKey="despesas" fill="var(--color-despesas)" radius={[4, 4, 0, 0]} />
      </BarChart>
    </ChartContainer>
  )
}

