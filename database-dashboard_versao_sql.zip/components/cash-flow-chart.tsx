"use client"

import { CartesianGrid, Legend, Line, LineChart, Tooltip, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { month: "Jan", entradas: 120000, saidas: 85000, saldo: 35000 },
  { month: "Fev", entradas: 135000, saidas: 90000, saldo: 45000 },
  { month: "Mar", entradas: 145000, saidas: 95000, saldo: 50000 },
  { month: "Abr", entradas: 160000, saidas: 100000, saldo: 60000 },
  { month: "Mai", entradas: 175000, saidas: 110000, saldo: 65000 },
  { month: "Jun", entradas: 162000, saidas: 105000, saldo: 57000 },
  { month: "Jul", entradas: 170000, saidas: 108000, saldo: 62000 },
  { month: "Ago", entradas: 180000, saidas: 112000, saldo: 68000 },
  { month: "Set", entradas: 190000, saidas: 115000, saldo: 75000 },
  { month: "Out", entradas: 185000, saidas: 118000, saldo: 67000 },
  { month: "Nov", entradas: 195000, saidas: 120000, saldo: 75000 },
  { month: "Dez", entradas: 210000, saidas: 125000, saldo: 85000 },
]

export function CashFlowChart() {
  return (
    <ChartContainer
      config={{
        entradas: {
          label: "Entradas",
          color: "hsl(var(--chart-1))",
        },
        saidas: {
          label: "Saídas",
          color: "hsl(var(--chart-2))",
        },
        saldo: {
          label: "Saldo",
          color: "hsl(var(--chart-4))",
        },
      }}
      className="h-[300px]"
    >
      <LineChart
        data={data}
        margin={{
          top: 5,
          right: 10,
          left: 10,
          bottom: 20,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={10} />
        <YAxis tickFormatter={(value) => `R$${value / 1000}k`} tickLine={false} axisLine={false} tickMargin={10} />
        <Tooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) => `${value}`}
              valueFormatter={(value) => `R$${value.toLocaleString("pt-BR")}`}
            />
          }
        />
        <Legend wrapperStyle={{ bottom: 0 }} />
        <Line
          type="monotone"
          dataKey="entradas"
          stroke="var(--color-entradas)"
          strokeWidth={2}
          dot={{ r: 4 }}
          activeDot={{ r: 6 }}
        />
        <Line
          type="monotone"
          dataKey="saidas"
          stroke="var(--color-saidas)"
          strokeWidth={2}
          dot={{ r: 4 }}
          activeDot={{ r: 6 }}
        />
        <Line
          type="monotone"
          dataKey="saldo"
          stroke="var(--color-saldo)"
          strokeWidth={3}
          dot={{ r: 4 }}
          activeDot={{ r: 6 }}
        />
      </LineChart>
    </ChartContainer>
  )
}

