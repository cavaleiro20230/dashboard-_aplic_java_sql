"use client"

import { useState } from "react"
import {
  type ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  type SortingState,
  useReactTable,
} from "@tanstack/react-table"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"

// Sample data
const data = [
  { id: 1, product: "Laptop", category: "Electronics", price: "R$ 3.599,00", sales: 42 },
  { id: 2, product: "Smartphone", category: "Electronics", price: "R$ 1.899,00", sales: 89 },
  { id: 3, product: "Headphones", category: "Electronics", price: "R$ 299,00", sales: 156 },
  { id: 4, product: "T-shirt", category: "Clothing", price: "R$ 59,90", sales: 210 },
  { id: 5, product: "Jeans", category: "Clothing", price: "R$ 129,90", sales: 98 },
  { id: 6, product: "Coffee Maker", category: "Home", price: "R$ 349,00", sales: 32 },
  { id: 7, product: "Blender", category: "Home", price: "R$ 199,00", sales: 45 },
  { id: 8, product: "Chocolate", category: "Food", price: "R$ 12,50", sales: 320 },
  { id: 9, product: "Pasta", category: "Food", price: "R$ 8,90", sales: 189 },
  { id: 10, product: "Notebook", category: "Other", price: "R$ 15,90", sales: 267 },
]

// Column definitions
const columns: ColumnDef<(typeof data)[0]>[] = [
  {
    accessorKey: "product",
    header: "Product",
  },
  {
    accessorKey: "category",
    header: "Category",
  },
  {
    accessorKey: "price",
    header: "Price",
  },
  {
    accessorKey: "sales",
    header: "Sales",
  },
]

export function DataTable() {
  const [sorting, setSorting] = useState<SortingState>([])

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
    state: {
      sorting,
    },
  })

  return (
    <div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  No results.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <div className="flex items-center justify-end space-x-2 py-4">
        <Button variant="outline" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>
          Previous
        </Button>
        <Button variant="outline" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
          Next
        </Button>
      </div>
    </div>
  )
}

