"use client"

import { Area, AreaChart, CartesianGrid, Tooltip, XAxis, YAxis } from "recharts"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

const data = [
  { month: "Jan", margem: 29.2 },
  { month: "Fev", margem: 33.3 },
  { month: "Mar", margem: 34.5 },
  { month: "Abr", margem: 37.5 },
  { month: "Mai", margem: 37.1 },
  { month: "Jun", margem: 35.2 },
  { month: "Jul", margem: 36.5 },
  { month: "Ago", margem: 37.8 },
  { month: "Set", margem: 39.5 },
  { month: "Out", margem: 36.2 },
  { month: "Nov", margem: 38.5 },
  { month: "Dez", margem: 40.5 },
]

export function ProfitMarginChart() {
  return (
    <ChartContainer
      config={{
        margem: {
          label: "Margem de Lucro",
          color: "hsl(var(--chart-3))",
        },
      }}
      className="h-[300px]"
    >
      <AreaChart
        data={data}
        margin={{
          top: 5,
          right: 10,
          left: 10,
          bottom: 20,
        }}
      >
        <CartesianGrid strokeDasharray="3 3" vertical={false} />
        <XAxis dataKey="month" tickLine={false} axisLine={false} tickMargin={10} />
        <YAxis
          tickFormatter={(value) => `${value}%`}
          domain={[0, 50]}
          tickLine={false}
          axisLine={false}
          tickMargin={10}
        />
        <Tooltip
          content={
            <ChartTooltipContent
              labelFormatter={(value) => `${value}`}
              valueFormatter={(value) => `${value.toFixed(1)}%`}
            />
          }
        />
        <Area
          type="monotone"
          dataKey="margem"
          stroke="var(--color-margem)"
          fill="var(--color-margem)"
          fillOpacity={0.2}
        />
      </AreaChart>
    </ChartContainer>
  )
}

