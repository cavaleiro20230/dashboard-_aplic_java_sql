"use client"

import { useState } from "react"
import {
  type ColumnDef,
  flexRender,
  getCoreRowModel,
  getPaginationRowModel,
  getSortedRowModel,
  type SortingState,
  useReactTable,
} from "@tanstack/react-table"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

// Sample data for receivables
const receivablesData = [
  {
    id: 1,
    cliente: "Empresa ABC Ltda",
    documento: "NF-e 12345",
    emissao: "15/05/2023",
    vencimento: "15/06/2023",
    valor: "R$ 12.500,00",
    status: "A vencer",
  },
  {
    id: 2,
    cliente: "Distribuidora XYZ S.A.",
    documento: "NF-e 12346",
    emissao: "10/05/2023",
    vencimento: "10/06/2023",
    valor: "R$ 8.750,00",
    status: "A vencer",
  },
  {
    id: 3,
    cliente: "Indústria 123 Ltda",
    documento: "NF-e 12347",
    emissao: "05/05/2023",
    vencimento: "05/06/2023",
    valor: "R$ 15.300,00",
    status: "A vencer",
  },
  {
    id: 4,
    cliente: "Comércio Rápido Ltda",
    documento: "NF-e 12348",
    emissao: "01/05/2023",
    vencimento: "01/06/2023",
    valor: "R$ 5.890,00",
    status: "A vencer",
  },
  {
    id: 5,
    cliente: "Serviços Gerais S.A.",
    documento: "NF-e 12349",
    emissao: "25/04/2023",
    vencimento: "25/05/2023",
    valor: "R$ 7.450,00",
    status: "Vencido",
  },
  {
    id: 6,
    cliente: "Transportadora Veloz",
    documento: "NF-e 12350",
    emissao: "20/04/2023",
    vencimento: "20/05/2023",
    valor: "R$ 9.200,00",
    status: "Vencido",
  },
  {
    id: 7,
    cliente: "Consultoria Eficaz",
    documento: "NF-e 12351",
    emissao: "15/04/2023",
    vencimento: "15/05/2023",
    valor: "R$ 11.800,00",
    status: "Vencido",
  },
  {
    id: 8,
    cliente: "Atacado & Varejo Ltda",
    documento: "NF-e 12352",
    emissao: "10/04/2023",
    vencimento: "10/05/2023",
    valor: "R$ 6.350,00",
    status: "Vencido",
  },
  {
    id: 9,
    cliente: "Supermercado Central",
    documento: "NF-e 12353",
    emissao: "05/04/2023",
    vencimento: "05/05/2023",
    valor: "R$ 18.750,00",
    status: "Vencido",
  },
  {
    id: 10,
    cliente: "Farmácia Saúde Total",
    documento: "NF-e 12354",
    emissao: "01/04/2023",
    vencimento: "01/05/2023",
    valor: "R$ 4.980,00",
    status: "Vencido",
  },
]

// Sample data for payables
const payablesData = [
  {
    id: 1,
    fornecedor: "Fornecedor A Ltda",
    documento: "NF-e 5678",
    emissao: "10/05/2023",
    vencimento: "10/06/2023",
    valor: "R$ 8.750,00",
    status: "A vencer",
  },
  {
    id: 2,
    fornecedor: "Fornecedor B S.A.",
    documento: "NF-e 5679",
    emissao: "08/05/2023",
    vencimento: "08/06/2023",
    valor: "R$ 12.300,00",
    status: "A vencer",
  },
  {
    id: 3,
    fornecedor: "Fornecedor C Ltda",
    documento: "NF-e 5680",
    emissao: "05/05/2023",
    vencimento: "05/06/2023",
    valor: "R$ 5.890,00",
    status: "A vencer",
  },
  {
    id: 4,
    fornecedor: "Fornecedor D S.A.",
    documento: "NF-e 5681",
    emissao: "01/05/2023",
    vencimento: "01/06/2023",
    valor: "R$ 7.450,00",
    status: "A vencer",
  },
  {
    id: 5,
    fornecedor: "Fornecedor E Ltda",
    documento: "NF-e 5682",
    emissao: "28/04/2023",
    vencimento: "28/05/2023",
    valor: "R$ 9.200,00",
    status: "A vencer",
  },
  {
    id: 6,
    fornecedor: "Fornecedor F S.A.",
    documento: "NF-e 5683",
    emissao: "25/04/2023",
    vencimento: "25/05/2023",
    valor: "R$ 11.800,00",
    status: "Vencido",
  },
  {
    id: 7,
    fornecedor: "Fornecedor G Ltda",
    documento: "NF-e 5684",
    emissao: "20/04/2023",
    vencimento: "20/05/2023",
    valor: "R$ 6.350,00",
    status: "Vencido",
  },
  {
    id: 8,
    fornecedor: "Fornecedor H S.A.",
    documento: "NF-e 5685",
    emissao: "15/04/2023",
    vencimento: "15/05/2023",
    valor: "R$ 18.750,00",
    status: "Vencido",
  },
  {
    id: 9,
    fornecedor: "Fornecedor I Ltda",
    documento: "NF-e 5686",
    emissao: "10/04/2023",
    vencimento: "10/05/2023",
    valor: "R$ 4.980,00",
    status: "Vencido",
  },
  {
    id: 10,
    fornecedor: "Fornecedor J S.A.",
    documento: "NF-e 5687",
    emissao: "05/04/2023",
    vencimento: "05/05/2023",
    valor: "R$ 14.250,00",
    status: "Vencido",
  },
]

// Column definitions for receivables
const receivablesColumns: ColumnDef<(typeof receivablesData)[0]>[] = [
  {
    accessorKey: "cliente",
    header: "Cliente",
  },
  {
    accessorKey: "documento",
    header: "Documento",
  },
  {
    accessorKey: "emissao",
    header: "Emissão",
  },
  {
    accessorKey: "vencimento",
    header: "Vencimento",
  },
  {
    accessorKey: "valor",
    header: "Valor",
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string
      return <Badge variant={status === "Vencido" ? "destructive" : "outline"}>{status}</Badge>
    },
  },
]

// Column definitions for payables
const payablesColumns: ColumnDef<(typeof payablesData)[0]>[] = [
  {
    accessorKey: "fornecedor",
    header: "Fornecedor",
  },
  {
    accessorKey: "documento",
    header: "Documento",
  },
  {
    accessorKey: "emissao",
    header: "Emissão",
  },
  {
    accessorKey: "vencimento",
    header: "Vencimento",
  },
  {
    accessorKey: "valor",
    header: "Valor",
  },
  {
    accessorKey: "status",
    header: "Status",
    cell: ({ row }) => {
      const status = row.getValue("status") as string
      return <Badge variant={status === "Vencido" ? "destructive" : "outline"}>{status}</Badge>
    },
  },
]

interface FinancialTableProps {
  type: "receivables" | "payables"
}

export function FinancialTable({ type }: FinancialTableProps) {
  const [sorting, setSorting] = useState<SortingState>([])

  const data = type === "receivables" ? receivablesData : payablesData
  const columns = type === "receivables" ? receivablesColumns : payablesColumns

  const table = useReactTable({
    data,
    columns,
    getCoreRowModel: getCoreRowModel(),
    getPaginationRowModel: getPaginationRowModel(),
    onSortingChange: setSorting,
    getSortedRowModel: getSortedRowModel(),
    state: {
      sorting,
    },
  })

  return (
    <div>
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            {table.getHeaderGroups().map((headerGroup) => (
              <TableRow key={headerGroup.id}>
                {headerGroup.headers.map((header) => {
                  return (
                    <TableHead key={header.id}>
                      {header.isPlaceholder ? null : flexRender(header.column.columnDef.header, header.getContext())}
                    </TableHead>
                  )
                })}
              </TableRow>
            ))}
          </TableHeader>
          <TableBody>
            {table.getRowModel().rows?.length ? (
              table.getRowModel().rows.map((row) => (
                <TableRow key={row.id} data-state={row.getIsSelected() && "selected"}>
                  {row.getVisibleCells().map((cell) => (
                    <TableCell key={cell.id}>{flexRender(cell.column.columnDef.cell, cell.getContext())}</TableCell>
                  ))}
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-24 text-center">
                  Nenhum resultado encontrado.
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
      <div className="flex items-center justify-end space-x-2 py-4">
        <Button variant="outline" size="sm" onClick={() => table.previousPage()} disabled={!table.getCanPreviousPage()}>
          Anterior
        </Button>
        <Button variant="outline" size="sm" onClick={() => table.nextPage()} disabled={!table.getCanNextPage()}>
          Próximo
        </Button>
      </div>
    </div>
  )
}

